@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0..\programa\bot.py" (
  echo ERROR: Extrae el parche dentro de EDUARDO-2.0.
  pause
  exit /b 1
)
if exist "%~dp0..\programa\.venv\Scripts\python.exe" (
  "%~dp0..\programa\.venv\Scripts\python.exe" "%~dp0INSTALADOR.py" 
) else (
  where py >nul 2>nul
  if not errorlevel 1 (
    py -3 "%~dp0INSTALADOR.py" 
  ) else (
    python "%~dp0INSTALADOR.py" 
  )
)
set "RESULTADO=%errorlevel%"
if not "%RESULTADO%"=="0" echo ERROR. No fuerces la instalacion.
pause
exit /b %RESULTADO%
