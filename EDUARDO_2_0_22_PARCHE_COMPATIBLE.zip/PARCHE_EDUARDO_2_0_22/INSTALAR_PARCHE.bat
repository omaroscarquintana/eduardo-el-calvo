@echo off
setlocal
cd /d "%~dp0"
set "RAIZ=%~dp0.."
if not exist "%RAIZ%\programa\bot.py" (
  echo ERROR: coloca esta carpeta PARCHE_EDUARDO_2_0_22 dentro de EDUARDO-2.0
  pause
  exit /b 1
)
set "PY=%RAIZ%\programa\.venv\Scripts\python.exe"
if exist "%PY%" (
  "%PY%" "%~dp0INSTALADOR.py"
) else (
  py -3 "%~dp0INSTALADOR.py"
)
if errorlevel 1 echo No se realizaron cambios completos. Revisa el mensaje anterior.
pause
