# -*- coding: utf-8 -*-
"""Parche Eduardo 2.0.22: regalos coherentes y 16 vestimentas. Solo dos archivos de codigo."""
import ast
import hashlib
import json
import os
import shutil
import sys
from datetime import datetime
from pathlib import Path

MARCA = "PARCHE_EDUARDO_2_0_22"
AQUI = Path(__file__).resolve().parent

def sha(datos):
    return hashlib.sha256(datos).hexdigest()

def encontrar_raiz():
    for ruta in [AQUI, AQUI.parent, *list(AQUI.parents)[:4]]:
        if (ruta / "programa" / "bot.py").is_file() and (ruta / "programa" / "eduardo" / "vestuario.py").is_file():
            return ruta.resolve()
    raise RuntimeError("No encuentro EDUARDO-2.0. Extrae la carpeta PARCHE_EDUARDO_2_0_22 DENTRO de EDUARDO-2.0.")

METODO_NUEVO = '''
    # PARCHE_EDUARDO_2_0_22: agradecimientos locales y diversos, sin demoras de IA
    def _agradecer_regalo_rapido(self, reac: Reaccion) -> str:
        nivel = reac.nivel
        quien = lista_nombres_regalos(reac.nombres) if nivel == "grupo" else reac.nombre
        quien = re.sub(r"\\\\s+", " ", str(quien or "chat")).strip()[:45]
        detalle = re.sub(r"\\\\s+", " ", str(reac.descripcion() or "tu regalo")).strip()[:58]
        if not self.filtro.es_seguro(detalle):
            detalle = "tu regalo"
        plantillas = {
            PEQUENO: [
                "¡Gracias, {n}!", "¡{n}, gracias por {r}!", "¡Gracias por el detalle, {n}!",
                "¡Muy amable, {n}!", "¡Gracias de corazón, {n}!", "¡{n}, se agradece!",
                "¡Gracias por acompañar con {r}, {n}!"
            ],
            "grupo": [
                "¡Gracias a todos por los regalos!", "¡Qué lindo, gracias por esta lluvia de regalos!",
                "¡Gracias, gente, qué buena onda!", "¡Se agradece muchísimo, chat!",
                "¡Gracias a todos, de verdad!", "¡Qué detalle de ustedes, gracias!"
            ],
            "mediano": [
                "¡{n}, qué lindo {r}! ¡Gracias!", "¡Gracias por {r}, {n}! ¡Me encantó!",
                "¡Muy bueno, {n}, gracias por ese regalo!", "¡{n}, te pasaste! ¡Muchas gracias!",
                "¡Qué buena onda, {n}! Gracias por {r}.",
                "¡Gracias, {n}! Ese regalo se hizo notar."
            ],
            GRANDE: [
                "¡Tremendo regalo, {n}! ¡Mil gracias por {r}!",
                "¡{n}, qué locura! ¡Gracias de corazón!",
                "¡Esto sí que es grande! ¡Gracias, {n}!",
                "¡{n}, impresionante ese {r}! ¡Te agradezco muchísimo!",
                "¡Enorme, {n}! ¡Qué regalazo, mil gracias!",
                "¡{n}, me dejaste sorprendido! ¡Gracias por {r}!"
            ],
            EPICO: [
                "¡NOOO, {n}! ¡Ese {r} fue una locura! ¡Mil gracias!",
                "¡{n}, espectacular! ¡Qué regalo impresionante, gracias de corazón!",
                "¡Pero mirá lo que mandaste, {n}! ¡Una bestialidad, mil gracias!",
                "¡{n}, esto es tremendo! ¡Te pasaste por completo, gracias!",
                "¡Increíble, {n}! ¡Regalazo épico! ¡Muchísimas gracias!",
                "¡{n}, qué momento! ¡Es enorme ese {r}, mil gracias!"
            ],
        }
        frases = plantillas.get(nivel, plantillas["mediano"])
        recientes = getattr(self, "_gracias_recientes_222", None)
        if recientes is None:
            recientes = deque(maxlen=12)
            self._gracias_recientes_222 = recientes
        disponibles = [(i, f) for i, f in enumerate(frases) if (nivel, i) not in recientes]
        if not disponibles:
            anterior = recientes[-1] if recientes else None
            disponibles = [(i, f) for i, f in enumerate(frases) if (nivel, i) != anterior]
        i, plantilla = random.choice(disponibles or list(enumerate(frases)))
        recientes.append((nivel, i))
        return plantilla.format(n=quien, r=detalle)

'''

CORTE_VIEJO = "        if es_capi or g.monedas > self.puntos_corte:"
CORTE_NUEVO = '        if g.monedas >= max(1000, int(getattr(self.regalos, "grande_desde", 1000) or 1000)):'
GESTO_VIEJO = '''        if reac.nivel in (GRANDE, EPICO):
            gesto, fuerza = "baile_capibara", 3
            if self.movimiento.gestos_auto and self.movimiento.festejar_regalos:
                gesto, fuerza = self.movimiento.gesto_hablar_regalo(reac.nivel, capibara=True)
'''
GESTO_NUEVO = '''        if reac.nivel in (GRANDE, EPICO):
            capi = bool(re.search(r"capi(?:bara)?|capybara|carpincho", reac.descripcion() or "", re.I))
            gesto, fuerza = ("baile_capibara" if capi else "festejo"), (3 if reac.nivel == EPICO else 2)
            if self.movimiento.gestos_auto and self.movimiento.festejar_regalos:
                sugerido = self.movimiento.gesto_hablar_regalo(reac.nivel, capibara=capi)
                if sugerido:
                    gesto, fuerza = sugerido
'''

NUEVOS_CONJUNTOS = '''
    # PARCHE_EDUARDO_2_0_22: 16 conjuntos que usan piezas ya existentes del motor 2D
    conjunto("vamp_rey_222", "Rey de Vampilandia", "Halloween", "👑", saco=True, traje_color="#17131e", camisa_estilo="vampiro", camisa_color="#30212a", cuello="corbatin", capa=True, capa_color="#14111d", forro_color="#a72640", sombrero="corona", collar="medallon", guantes="negros"),
    conjunto("vamp_guardia_222", "Guardián del castillo", "Halloween", "🛡️", saco=True, traje_color="#151922", camisa_estilo="vestir", camisa_color="#343842", capa=True, capa_color="#171a22", forro_color="#763b48", cuello="corbata", cuello_color="#ad354e", guantes="negros"),
    conjunto("vamp_obsidiana_222", "Conde Obsidiana", "Halloween", "🧛", saco=True, traje_color="#0d0d13", camisa_estilo="vampiro", camisa_color="#1a1722", capa=True, capa_color="#101016", forro_color="#4d243e", cuello="corbatin", collar="medallon"),
    conjunto("vamp_rubi_222", "Señor del rubí", "Halloween", "💎", saco=True, traje_color="#191019", camisa_estilo="vampiro", camisa_color="#361822", cuello="corbatin", cuello_color="#ad2546", capa=True, capa_color="#1d101b", forro_color="#ab2845", collar="medallon"),
    conjunto("vamp_carmesi_222", "Príncipe Carmesí", "Halloween", "🌹", saco=True, traje_color="#552334", camisa_estilo="smoking", camisa_color="#e5d9d2", cuello="corbatin", capa=True, capa_color="#2b1926", forro_color="#b33a50", reloj="dorado"),
    conjunto("vamp_sombra_222", "Sombra Nocturna", "Halloween", "🌑", saco=True, traje_color="#10141b", camisa_estilo="vampiro", camisa_color="#181820", capa=True, capa_color="#11141d", forro_color="#292a3f", guantes="negros", collar="cadena_plata"),
    conjunto("gala_total_222", "Esmoquin negro total", "Elegantes", "🖤", saco=True, traje_color="#0f1015", camisa_estilo="smoking", camisa_color="#e8e6e6", cuello="corbatin", cuello_color="#17171b", reloj="plateado"),
    conjunto("gala_plata_222", "Gala plateada", "Elegantes", "✨", saco=True, traje_color="#5b6272", camisa_estilo="vestir", camisa_color="#e1e2e8", cuello="corbata", cuello_color="#252b39", panuelo="blanco", reloj="plateado"),
    conjunto("magnate_222", "Magnate de medianoche", "Elegantes", "💼", saco=True, traje_color="#22253a", camisa_estilo="vestir", camisa_color="#d9d6dc", cuello="corbata", cuello_color="#b28a42", reloj="dorado", panuelo="dorado"),
    conjunto("mafioso_222", "Caballero de cine negro", "Elegantes", "🎩", saco=True, traje_color="#212128", camisa_estilo="vestir", camisa_color="#d6d2c6", cuello="corbata", cuello_color="#4c4c56", sombrero="copa", guantes="negros"),
    conjunto("rock_gotico_222", "Rock gótico", "Casuales", "⚡", camisa_estilo="camiseta", camisa_color="#17151b", estampado="rayo", estampado_color="#be3150", collar="cadena_plata", reloj="negro", guantes="negros"),
    conjunto("urbano_negro_222", "Urbano negro", "Casuales", "🧢", camisa_estilo="buzo", camisa_color="#191b23", estampado="luna", estampado_color="#848096", sombrero="gorra", reloj="negro"),
    conjunto("deporte_rojo_222", "Deportivo rojo", "Casuales", "🏅", camisa_estilo="polo", camisa_color="#a52c40", camisa_color2="#e0d9d5", sombrero="gorra", reloj="negro"),
    conjunto("detective_222", "Detective Noir", "Personajes", "🔎", saco=True, traje_color="#3b3542", camisa_estilo="vestir", camisa_color="#c9c3bc", cuello="corbata", cuello_color="#27212c", sombrero="copa", guantes="negros"),
    conjunto("navidad_oscura_222", "Navidad nocturna", "Celebraciones", "🎄", camisa_color="#672d3b", camisa_color2="#e4d9c9", sombrero="santa", estampado="estrella", estampado_color="#d7b35d", guantes="negros"),
    conjunto("mvp_leyenda_222", "MVP de leyenda", "Elegantes", "🏆", saco=True, traje_color="#251e33", camisa_estilo="smoking", camisa_color="#eee2d7", cuello="corbatin", cuello_color="#b18a35", sombrero="corona", capa=True, capa_color="#211927", forro_color="#8c2941", collar="medallon"),
'''

def nuevo_bot(texto):
    if "def _agradecer_regalo_rapido(" in texto:
        raise RuntimeError("bot.py ya fue modificado: no voy a instalar dos veces ni mezclar parches.")
    if texto.count(CORTE_VIEJO) != 1:
        raise RuntimeError("bot.py tiene una logica de regalos distinta. No se modifica nada.")
    inicio = texto.find("    async def _hablar_regalo(")
    fin = texto.find("    async def _hablar_meta(", inicio)
    if inicio < 0 or fin < 0:
        raise RuntimeError("No encuentro el bloque de regalos que esperaba en bot.py.")
    bloque = texto[inicio:fin]
    primero = bloque.find('        texto, gesto, origen = None, "", "frase"')
    ultimo = bloque.find("        fuerza = 1", primero)
    if primero < 0 or ultimo < 0 or GESTO_VIEJO not in bloque:
        raise RuntimeError("El comportamiento de regalos difiere del enviado: instalacion cancelada.")
    bloque = (bloque[:primero] + '        texto, gesto, origen = self._agradecer_regalo_rapido(reac), "", "frase local"\n'
              + bloque[ultimo:])
    bloque = bloque.replace(GESTO_VIEJO, GESTO_NUEVO, 1)
    texto = texto[:inicio] + METODO_NUEVO + bloque + texto[fin:]
    texto = texto.replace(CORTE_VIEJO, CORTE_NUEVO, 1)
    texto = texto.replace('"""Un regalo de más de 10 puntos corta la frase en curso para agradecer ya."""',
                          '"""Solo los regalos grandes interrumpen la voz en curso."""', 1)
    texto = texto.replace("✂️  Corto lo que estaba diciendo: llegó un regalo de más de 10 puntos.",
                          "✂️  Interrupcion por regalo grande.", 1)
    texto = texto.replace("cortado: regalo de más de 10 puntos", "cortado: regalo grande", 1)
    ast.parse(texto, filename="bot.py")
    return texto

def nuevo_vestuario(texto):
    if MARCA in texto:
        raise RuntimeError("vestuario.py ya tiene estos conjuntos: no repito la instalacion.")
    if "CONJUNTOS = [" not in texto or not texto.rstrip().endswith("]"):
        raise RuntimeError("Estructura de vestuario.py incompatible.")
    for ident in ("vamp_rey_222", "mvp_leyenda_222"):
        if ('conjunto("' + ident + '"') in texto:
            raise RuntimeError("Ya existe uno de los conjuntos nuevos.")
    cierre = texto.rfind("\n]")
    if cierre < 0:
        raise RuntimeError("No encuentro el final de la lista de vestimentas.")
    texto = texto[:cierre] + "\n" + NUEVOS_CONJUNTOS.rstrip("\n") + texto[cierre:]
    ast.parse(texto, filename="vestuario.py")
    return texto

def rutas(root):
    return {
        "bot.py": root / "programa" / "bot.py",
        "vestuario.py": root / "programa" / "eduardo" / "vestuario.py",
    }

def escribir_seguro(destino, datos):
    temp = destino.with_name(destino.name + ".parche_222.tmp")
    try:
        temp.write_bytes(datos)
        shutil.copymode(destino, temp)
        os.replace(temp, destino)
    finally:
        if temp.exists():
            temp.unlink()

def instalar(root):
    archivos = rutas(root)
    previos = {n: p.read_bytes() for n, p in archivos.items()}
    textos = {n: b.decode("utf-8-sig") for n, b in previos.items()}
    if "def _agradecer_regalo_rapido(" in textos["bot.py"] and MARCA in textos["vestuario.py"]:
        print("El parche 2.0.22 ya esta instalado. No hice cambios.")
        return
    if "def _agradecer_regalo_rapido(" in textos["bot.py"] or MARCA in textos["vestuario.py"]:
        raise RuntimeError("Detecte una instalacion parcial o diferente. No toco nada.")
    nuevos = {
        "bot.py": nuevo_bot(textos["bot.py"]).encode("utf-8"),
        "vestuario.py": nuevo_vestuario(textos["vestuario.py"]).encode("utf-8"),
    }
    # Comprobacion previa de ambos modulos sin ejecutarlos ni importar memoria.
    for nombre, datos in nuevos.items():
        compile(datos.decode("utf-8"), nombre, "exec")
    sello = datetime.now().strftime("%Y%m%d_%H%M%S")
    respaldo = root / "RESPALDOS_EDUARDO_2_0_22" / sello
    respaldo.mkdir(parents=True, exist_ok=False)
    for nombre, datos in previos.items():
        (respaldo / nombre).write_bytes(datos)
    manifiesto = {
        "archivos": {n: {"antes": sha(previos[n]), "despues": sha(nuevos[n])} for n in archivos},
        "fecha": sello, "restaurado": False,
    }
    (respaldo / "manifiesto.json").write_text(json.dumps(manifiesto, indent=2), encoding="utf-8")
    cambiados = []
    try:
        for nombre, destino in archivos.items():
            escribir_seguro(destino, nuevos[nombre])
            cambiados.append(nombre)
    except Exception:
        for nombre in cambiados:
            escribir_seguro(archivos[nombre], previos[nombre])
        raise
    print("PARCHE 2.0.22 INSTALADO.")
    print("16 vestimentas nuevas y agradecimientos sin consultas a Gemini.")
    print("No se modifico memoria.json, config.toml, datos, voces ni panel.")
    print("Respaldo:", respaldo)

def restaurar(root):
    base = root / "RESPALDOS_EDUARDO_2_0_22"
    if not base.exists():
        raise RuntimeError("No hay respaldos del parche.")
    respaldos = sorted((p for p in base.iterdir() if (p / "manifiesto.json").exists()), reverse=True)
    rutas_actuales = rutas(root)
    for carpeta in respaldos:
        m = json.loads((carpeta / "manifiesto.json").read_text(encoding="utf-8"))
        if m.get("restaurado"):
            continue
        originales = {n: (carpeta / n).read_bytes() for n in rutas_actuales}
        for n, ruta in rutas_actuales.items():
            actual = sha(ruta.read_bytes())
            if actual != m["archivos"][n]["despues"]:
                raise RuntimeError("El archivo " + n + " cambio desde el parche. No sobrescribo cambios posteriores.")
        for n, ruta in rutas_actuales.items():
            escribir_seguro(ruta, originales[n])
        m["restaurado"] = True
        (carpeta / "manifiesto.json").write_text(json.dumps(m, indent=2), encoding="utf-8")
        print("Version anterior restaurada. Las memorias y configuraciones no se tocaron.")
        return
    raise RuntimeError("No quedan instalaciones de este parche pendientes de restaurar.")

if __name__ == "__main__":
    try:
        raiz = encontrar_raiz()
        print("Instalacion encontrada:", raiz)
        print("Antes de continuar, cierra Eduardo y su panel.")
        if "--restaurar" in sys.argv:
            restaurar(raiz)
        else:
            instalar(raiz)
    except Exception as error:
        print("\nPARCHE NO APLICADO:", error)
        sys.exit(1)
